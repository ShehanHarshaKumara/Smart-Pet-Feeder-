import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import '../models/feeder_schedule.dart';
import '../services/firebase_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const DashboardPage(),
      const SchedulePage(),
      const ManualControlPage(),
      const SettingsPage(),
    ];

    return Scaffold(
      body: pages[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.schedule_rounded), label: 'Schedule'),
          NavigationDestination(icon: Icon(Icons.tune_rounded), label: 'Control'),
          NavigationDestination(icon: Icon(Icons.settings_rounded), label: 'Settings'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: StreamBuilder<DatabaseEvent>(
        stream: FirebaseService.instance.deviceStream(),
        builder: (context, snapshot) {
          final data = snapshot.data?.snapshot.value as Map<dynamic, dynamic>? ?? {};
          final status = data['status'] as Map<dynamic, dynamic>? ?? {};
          final settings = data['settings'] as Map<dynamic, dynamic>? ?? {};
          final foodLevel = status['foodLevel']?.toString() ?? '75';
          final waterLevel = status['waterLevel']?.toString() ?? '80';
          final nextMeal = status['nextMeal']?.toString() ?? '12:30 PM';
          final online = status['online'] == true;
          final autoMode = settings['autoMode'] == true;

          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Smart Pet Feeder', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                      SizedBox(height: 4),
                      Text('Food & Water IoT Controller'),
                    ],
                  ),
                  CircleAvatar(
                    backgroundColor: online ? Colors.green.shade100 : Colors.red.shade100,
                    child: Icon(Icons.wifi_rounded, color: online ? Colors.green : Colors.red),
                  ),
                ],
              ),
              const SizedBox(height: 22),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF0284C7), Color(0xFF38BDF8)]),
                  borderRadius: BorderRadius.circular(26),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.pets_rounded, color: Colors.white, size: 52),
                    const SizedBox(height: 18),
                    Text('Next Meal: $nextMeal', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text(autoMode ? 'Auto mode is enabled' : 'Manual mode is enabled', style: const TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(child: _LevelCard(title: 'Food Level', value: '$foodLevel%', icon: Icons.restaurant_rounded)),
                  const SizedBox(width: 14),
                  Expanded(child: _LevelCard(title: 'Water Level', value: '$waterLevel%', icon: Icons.water_drop_rounded)),
                ],
              ),
              const SizedBox(height: 18),
              const Text('Quick Actions', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => FirebaseService.instance.feedNow(),
                      icon: const Icon(Icons.restaurant),
                      label: const Text('Feed Now'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.tonalIcon(
                      onPressed: () => FirebaseService.instance.waterNow(),
                      icon: const Icon(Icons.water_drop),
                      label: const Text('Water Now'),
                    ),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }
}

class _LevelCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const _LevelCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 34, color: const Color(0xFF0284C7)),
          const SizedBox(height: 16),
          Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          Text(title),
        ],
      ),
    );
  }
}

class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key});
  @override
  State<SchedulePage> createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  String _type = 'Food';

  Future<void> _addSchedule() async {
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (time == null || !mounted) return;
    final formatted = time.format(context);
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await FirebaseService.instance.saveSchedule(id: id, time: formatted, type: _type, enabled: true);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Feeding Schedule', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'Food', label: Text('Food'), icon: Icon(Icons.restaurant)),
              ButtonSegment(value: 'Water', label: Text('Water'), icon: Icon(Icons.water_drop)),
            ],
            selected: {_type},
            onSelectionChanged: (value) => setState(() => _type = value.first),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(onPressed: _addSchedule, icon: const Icon(Icons.add), label: const Text('Add Schedule')),
          const SizedBox(height: 18),
          StreamBuilder<DatabaseEvent>(
            stream: FirebaseDatabase.instance.ref('smart_pet_feeder/schedules').onValue,
            builder: (context, snapshot) {
              final raw = snapshot.data?.snapshot.value as Map<dynamic, dynamic>? ?? {};
              final schedules = raw.entries
                  .map((e) => FeederSchedule.fromMap(e.key.toString(), e.value as Map<dynamic, dynamic>))
                  .toList();
              if (schedules.isEmpty) return const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('No schedules yet')));
              return Column(
                children: schedules.map((item) {
                  return Card(
                    child: ListTile(
                      leading: Icon(item.type == 'Food' ? Icons.restaurant : Icons.water_drop),
                      title: Text(item.time, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(item.type),
                      trailing: Wrap(
                        children: [
                          Switch(value: item.enabled, onChanged: (v) => FirebaseService.instance.updateScheduleStatus(item.id, v)),
                          IconButton(icon: const Icon(Icons.delete), onPressed: () => FirebaseService.instance.deleteSchedule(item.id)),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}

class ManualControlPage extends StatelessWidget {
  const ManualControlPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Manual Control', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            _ActionPanel(title: 'Food Dispensing', icon: Icons.restaurant, buttonText: 'Dispense Food', onTap: FirebaseService.instance.feedNow),
            const SizedBox(height: 16),
            _ActionPanel(title: 'Water Supply', icon: Icons.water_drop, buttonText: 'Supply Water', onTap: FirebaseService.instance.waterNow),
          ],
        ),
      ),
    );
  }
}

class _ActionPanel extends StatelessWidget {
  final String title;
  final IconData icon;
  final String buttonText;
  final VoidCallback onTap;
  const _ActionPanel({required this.title, required this.icon, required this.buttonText, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26)),
      child: Column(
        children: [
          Icon(icon, size: 70, color: const Color(0xFF0284C7)),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          FilledButton(onPressed: onTap, child: Text(buttonText)),
        ],
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: StreamBuilder<DatabaseEvent>(
        stream: FirebaseService.instance.deviceStream(),
        builder: (context, snapshot) {
          final data = snapshot.data?.snapshot.value as Map<dynamic, dynamic>? ?? {};
          final settings = data['settings'] as Map<dynamic, dynamic>? ?? {};
          final autoMode = settings['autoMode'] == true;

          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              const Text('Settings', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 18),
              Card(
                child: SwitchListTile(
                  title: const Text('Automatic Mode'),
                  subtitle: const Text('Use saved schedules to dispense food and water'),
                  value: autoMode,
                  onChanged: FirebaseService.instance.setAutoMode,
                ),
              ),
              const Card(
                child: ListTile(
                  leading: Icon(Icons.info_outline),
                  title: Text('Firebase Path'),
                  subtitle: Text('smart_pet_feeder/status, settings, commands, schedules'),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
