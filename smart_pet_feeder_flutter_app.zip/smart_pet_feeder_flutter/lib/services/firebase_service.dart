import 'package:firebase_database/firebase_database.dart';

class FirebaseService {
  FirebaseService._();
  static final FirebaseService instance = FirebaseService._();

  final DatabaseReference _db = FirebaseDatabase.instance.ref('smart_pet_feeder');

  Stream<DatabaseEvent> deviceStream() => _db.onValue;

  Future<void> feedNow() async {
    await _db.child('commands').update({
      'feedNow': true,
      'lastCommand': 'Food dispense requested',
      'updatedAt': ServerValue.timestamp,
    });
  }

  Future<void> waterNow() async {
    await _db.child('commands').update({
      'waterNow': true,
      'lastCommand': 'Water supply requested',
      'updatedAt': ServerValue.timestamp,
    });
  }

  Future<void> setAutoMode(bool enabled) async {
    await _db.child('settings').update({'autoMode': enabled});
  }

  Future<void> saveSchedule({
    required String id,
    required String time,
    required String type,
    required bool enabled,
  }) async {
    await _db.child('schedules/$id').set({
      'time': time,
      'type': type,
      'enabled': enabled,
      'createdAt': ServerValue.timestamp,
    });
  }

  Future<void> updateScheduleStatus(String id, bool enabled) async {
    await _db.child('schedules/$id').update({'enabled': enabled});
  }

  Future<void> deleteSchedule(String id) async {
    await _db.child('schedules/$id').remove();
  }
}
