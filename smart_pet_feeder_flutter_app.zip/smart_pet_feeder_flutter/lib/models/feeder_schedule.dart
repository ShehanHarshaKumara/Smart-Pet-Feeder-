class FeederSchedule {
  final String id;
  final String time;
  final String type;
  final bool enabled;

  FeederSchedule({
    required this.id,
    required this.time,
    required this.type,
    required this.enabled,
  });

  factory FeederSchedule.fromMap(String id, Map<dynamic, dynamic> data) {
    return FeederSchedule(
      id: id,
      time: data['time']?.toString() ?? '--:--',
      type: data['type']?.toString() ?? 'Food',
      enabled: data['enabled'] == true,
    );
  }
}
