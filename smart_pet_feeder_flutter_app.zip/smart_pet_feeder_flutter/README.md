# Smart Pet Feeder Flutter App

Flutter mobile app for an IoT Smart Pet Feeder with food and water supply control.

## Features
- Dashboard with food/water level
- Feed Now button
- Water Now button
- Add food/water schedules
- Firebase Realtime Database connection
- Auto/manual mode

## Firebase Database Structure
```json
{
  "smart_pet_feeder": {
    "status": {
      "online": true,
      "foodLevel": 75,
      "waterLevel": 80,
      "nextMeal": "12:30 PM"
    },
    "settings": {
      "autoMode": true
    },
    "commands": {
      "feedNow": false,
      "waterNow": false
    },
    "schedules": {}
  }
}
```

## Setup
1. Run `flutter pub get`
2. Create a Firebase project
3. Enable Realtime Database
4. Install FlutterFire CLI
5. Run `flutterfire configure`
6. Run `flutter run`
